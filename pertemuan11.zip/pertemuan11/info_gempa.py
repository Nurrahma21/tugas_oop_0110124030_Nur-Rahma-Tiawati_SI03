from Gempa import *

print('Hello reporter Rahma mengabarkan')
gempa1 = Gempa(1.2, "Banten")
gempa2 = Gempa(6.2, "palu")
gempa3 = Gempa(5.6, "Cianjur")
gempa4 = Gempa(3.3, "Jayapura")
gempa5 = Gempa(4.0, "Garut")

gempa1.dampak()
gempa2.dampak()
gempa3.dampak()
gempa4.dampak()
gempa5.dampak()
